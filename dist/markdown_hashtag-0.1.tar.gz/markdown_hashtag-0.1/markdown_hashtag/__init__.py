from .hashtag import HashtagExtension, makeExtension
